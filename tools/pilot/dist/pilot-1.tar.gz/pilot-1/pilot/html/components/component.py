class Component:

    pass

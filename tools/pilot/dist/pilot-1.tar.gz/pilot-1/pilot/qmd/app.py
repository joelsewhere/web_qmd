import sys 
import logging
from pilot.qmd.render import render
from uvicorn.supervisors import basereload
import sh

logger = logging.getLogger("uvicorn.error")

class BaseReload(basereload.BaseReload):

    def run(self) -> None:
        self.startup()
        for changes in self:
            if changes:
                changes = list(changes)
                for change in changes:
                    if change.suffix == '.qmd':
                        sh.cd(self.config.root_path)
                        render(change, self.config.root_path, logger=logger)
                logger.warning(
                    "%s detected changes in %s. Reloading...",
                    self.reloader_name,
                    ", ".join(map(basereload._display_path, changes)),
                )

                self.restart()

        self.shutdown()

basereload.BaseReload = BaseReload

def uncache(exclude):
    """Remove package modules from cache except excluded ones.
    On next import they will be reloaded.

    Args:
        exclude (iter<str>): Sequence of module paths.

    Thank you! https://medium.com/@chipiga86/python-monkey-patching-like-a-boss-87d7ddb8098e
    """
    pkgs = []
    for mod in exclude:
        pkg = mod.split('.', 1)[0]
        pkgs.append(pkg)

    to_uncache = []
    for mod in sys.modules:
        if mod in exclude:
            continue

        if mod in pkgs:
            to_uncache.append(mod)
            continue

        for pkg in pkgs:
            if mod.startswith(pkg + '.'):
                to_uncache.append(mod)
                break

    for mod in to_uncache:
        del sys.modules[mod]


uncache(['uvicorn._subprocess', 'uvicorn.supervisors.basereload'])



import os
import inspect
import uvicorn
from typing import List
from pathlib import Path
from fasthtml.common import fast_app, Body
from pilot.utils.load_module import load_module
from pilot.html.components.combined import CombinedComponent

def qmd_app(
        project_root: Path,
        pico=False,
        hdrs=(),
        qmd_directories:List[Path]=[],
        headers = [],
        footers = [],
        ):
    

    app,rt = fast_app(
        pico=pico,
        hdrs=hdrs,
    )

    import pilot
    setattr(pilot, 'app', app)

    app.root_path = project_root.as_posix()
    app.router.redirect_slashes = False 

    def create_endpoint(endpoint, group):

        
        @rt(endpoint, include_in_schema=False)
        def get(location:str=''):
            
            layout_path = group / location / 'layout.py'
            page_layout = load_module(layout_path).layout

            class PageLayout(CombinedComponent):

                outer_tag_type = Body
                children = []

                if page_layout.headers:
                
                    children += headers

                children.append(page_layout)

                if page_layout.footers:

                    children += footers

            layout = PageLayout()

            return layout()


    for directory in qmd_directories:

        group_indicator = directory / '.qmd_page_group'
        if not group_indicator.is_file():
            group_indicator.open('w').write('')

        endpoint = f'/{directory.stem}/' + '{location:str}'  
        create_endpoint(endpoint, directory)
        
        directory_path = f'/{directory.stem}'
        create_endpoint(directory_path, directory)

        for route_file in directory.rglob('routes.py'):
            load_module(route_file)


# Copy of the fasthtml.core::serve
# The function in fasthtml doesn't 


    def serve(
            appname=None, # Name of the module
            app='app', # App instance to be served
            host='0.0.0.0', # If host is 0.0.0.0 will convert to localhost
            port=None, # If port is None it will default to 5001 or the PORT environment variable
            reload=True, # Default is to reload the app upon code changes
            reload_includes:list[str]|str|None=None, # Additional files to watch for changes
            reload_excludes:list[str]|str|None=None # Files to ignore for changes
            ): 
        "Run the app in an async server, with live reload set as the default."
        bk = inspect.currentframe().f_back
        glb = bk.f_globals
        code = bk.f_code
        if not appname:
            if glb.get('__name__')=='__main__': appname = Path(glb.get('__file__', '')).stem
            elif code.co_name=='main' and bk.f_back.f_globals.get('__name__')=='__main__': appname = inspect.getmodule(bk).__name__
        if appname:
            if not port: port=int(os.getenv("PORT", default=5001))
            uvicorn.run(
                f'{appname}:{app}',
                host=host,
                port=port,
                reload=reload,
                reload_includes=["*.qmd"],
                reload_excludes=reload_excludes,
                root_path=project_root.as_posix()
                )
    
            
    return app, rt, serve
